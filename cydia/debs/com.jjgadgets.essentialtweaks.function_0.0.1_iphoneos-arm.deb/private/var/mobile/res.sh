echo Changing screen resolution...
/bin/cp /private/var/mobile/Library/Preferences/com.apple.iokit.IOMobileGraphicsFamily.plist.setrestarget.bak /private/var/mobile/Library/Preferences/com.apple.iokit.IOMobileGraphicsFamily.plist
sleep 1
echo Screen resolution changed!
sleep 1
echo Applying new resolution...
crux /usr/bin/killall cfprefsd
sleep 1
echo New resolution applied!
sleep 1
echo Reloading SpringBoard...
crux /usr/bin/killall -SEGV backboardd
crux /usr/bin/killall backboardd
sleep 100
/bin/cp /private/var/mobile/Library/Preferences/com.apple.iokit.IOMobileGraphicsFamily.plist.setresoriginal.bak /private/var/mobile/Library/Preferences/com.apple.iokit.IOMobileGraphicsFamily.plist